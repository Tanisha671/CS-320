package Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import Contact.Contact;
import Contact.ContactService;

public class ContactServiceTest {

    private ContactService contactService;

    @BeforeEach
    public void setUp() {
        contactService = new ContactService();
    }

    @Test
    public void testAddContact() {
        Contact contact = new Contact("1234", "Zion", "Dun", "1234567890", "Lane St");

        // Add the contact
        contactService.addContact(contact);

        // Verify the contact is added successfully
        assertEquals(contact, contactService.getContact("1234"));
    }

    @Test
    public void testAddContactWithNullContact() {
        // Attempt to add a null contact (should throw an exception)
        assertThrows(IllegalArgumentException.class, () -> contactService.addContact(null));
    }

    @Test
    public void testAddContactWithDuplicateId() {
        Contact contact1 = new Contact("1234", "Zion", "Dun", "1234567890", "Lane St");
        Contact contact2 = new Contact("1234", "Judy", "Smith", "0987654321", "Second St");

        // Add the first contact
        contactService.addContact(contact1);

        // Attempt to add the second contact with the same ID (should throw an exception)
        assertThrows(IllegalArgumentException.class, () -> contactService.addContact(contact2));
    }

    @Test
    public void testDeleteContact() {
        Contact contact = new Contact("1234", "Zion", "Dun", "1234567890", "Lane St");

        // Add the contact
        contactService.addContact(contact);

        // Delete the contact
        contactService.deleteContact("1234");

        // Verify the contact is deleted
        assertNull(contactService.getContact("1234"));
    }

    @Test
    public void testDeleteNullContactId() {
        // Attempt to delete a contact with a null ID (should throw an exception)
        assertThrows(IllegalArgumentException.class, () -> contactService.deleteContact(null));
    }

    @Test
    public void testDeleteContactWithNonExistingId() {
        // Attempt to delete a contact that doesn't exist (should throw an exception)
        assertThrows(IllegalArgumentException.class, () -> contactService.deleteContact("9999"));
    }

    @Test
    public void testUpdateContact() {
        // Creating a contact instance
        Contact contact = new Contact("1234", "Zion", "Dun", "1234567890", "Lane St");

        // Add the contact to the contact service
        contactService.addContact(contact);

    }

    @Test
    public void testUpdateContactWithNonExistingId() {
        // Attempt to update a contact that doesn't exist (should throw an exception)
        assertThrows(IllegalArgumentException.class, () -> contactService.updateContact("9999", "Updated Zion", "Updated Dun", "0987654321", "Updated Lane St"));
    }

    @Test
    public void testUpdateContactWithNullValues() {
        Contact contact = new Contact("1234", "Zion", "Dun", "1234567890", "Lane St");

        // Add the contact
        contactService.addContact(contact);

        // Update only the phone and address
        contactService.updateContact("1234", null, null, "0987654321", "Updated Lane St");

        // Verify only the phone and address are updated
        Contact updatedContact = contactService.getContact("1234");
        assertEquals("Zion", updatedContact.getFirstName());
        assertEquals("Dun", updatedContact.getLastName());
        assertEquals("0987654321", updatedContact.getPhone());
        assertEquals("Updated Lane St", updatedContact.getAddress());
    }

    @Test
    public void testGetContact() {
        Contact contact = new Contact("1234", "Zion", "Dun", "1234567890", "Lane St");

        // Add the contact
        contactService.addContact(contact);

        // Verify the contact is retrieved successfully
        assertEquals(contact, contactService.getContact("1234"));
    }

    @Test
    public void testGetContactWithNonExistingId() {
        // Attempt to get a contact that doesn't exist (should return null)
        assertNull(contactService.getContact("9999"));
    }
}

