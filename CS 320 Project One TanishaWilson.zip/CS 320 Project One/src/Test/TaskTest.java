package Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import Task.Task;  // Make sure to import the Task class

public class TaskTest {

    @Test
    public void testTaskCreation() {
        // Create a Task object
        Task task = new Task("1", "Test Task", "This is a test task.");

        // Verify the Task properties
        assertNotNull(task);
        assertEquals("1", task.getTaskId());
        assertEquals("Test Task", task.getName());
        assertEquals("This is a test task.", task.getDescription());
    }

    @Test
    public void testSetters() {
        // Create a Task object
        Task task = new Task("1", "Test", "Description");

        // Update name and description
        task.setName("Updated Name");
        task.setDescription("Updated Description");

        // Verify updated values
        assertEquals("Updated Name", task.getName());
        assertEquals("Updated Description", task.getDescription());
    }

   
    // Edge case tests (add these below your existing tests)

    @Test
    public void testValidTaskIdLength() {
        // Ensure task ID of exactly 10 characters is valid
        Task task = new Task("1234567890", "Valid Task", "Valid Description");
        assertEquals("1234567890", task.getTaskId());
    }

    @Test
    public void testValidNameLength() {
        // Ensure name of exactly 20 characters is valid
        Task task = new Task("1", "12345678901234567890", "Valid Description");
        assertEquals("12345678901234567890", task.getName());
    }

    @Test
    public void testValidDescriptionLength() {
        // Ensure description of exactly 50 characters is valid
        Task task = new Task("1", "Test Task", "1234567890123456789012345678901234567890123450");
        assertEquals("1234567890123456789012345678901234567890123450", task.getDescription());
    }
}
