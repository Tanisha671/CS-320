package Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import Task.Task;
import Task.TaskService;

public class TaskServiceTest {

    private TaskService taskService;

    @BeforeEach
    public void setUp() {
        taskService = new TaskService();
    }

    @Test
    public void testAddTask() {
        Task task = new Task("1", "Test Task", "Test Description");

        // Add a task
        taskService.addTask(task);

        // Verify the task is added successfully
        assertEquals(task, taskService.getTask("1"));
    }

    @Test
    public void testAddTaskWithDuplicateId() {
        Task task1 = new Task("1", "Test Task", "Test Description");
        Task task2 = new Task("1", "Another Task", "Another Description");

        // Add the first task
        taskService.addTask(task1);

        // Attempt to add another task with the same ID (should throw an exception)
        assertThrows(IllegalArgumentException.class, () -> taskService.addTask(task2));
    }

    @Test
    public void testAddNullTask() {
        // Attempt to add a null task (should throw an exception)
        assertThrows(IllegalArgumentException.class, () -> taskService.addTask(null));
    }

    @Test
    public void testDeleteTask() {
        Task task = new Task("1", "Test Task", "Test Description");

        // Add the task
        taskService.addTask(task);

        // Delete the task
        taskService.deleteTask("1");

        // Verify the task is deleted
        assertNull(taskService.getTask("1"));
    }

    @Test
    public void testDeleteTaskWithNonExistingId() {
        // Attempt to delete a task that doesn't exist (should throw an exception)
        assertThrows(IllegalArgumentException.class, () -> taskService.deleteTask("999"));
    }

    @Test
    public void testDeleteNullTaskId() {
        // Attempt to delete a task with a null ID (should throw an exception)
        assertThrows(IllegalArgumentException.class, () -> taskService.deleteTask(null));
    }

    @Test
    public void testUpdateTask() {
        Task task = new Task("1", "Test Task", "Test Description");

        // Add the task
        taskService.addTask(task);

        // Update the task
        taskService.updateTask("1", "Updated Task", "Updated Description");

        // Verify the task is updated
        assertEquals("Updated Task", task.getName());
        assertEquals("Updated Description", task.getDescription());
    }

    @Test
    public void testUpdateTaskWithNonExistingId() {
        // Attempt to update a task that doesn't exist (should throw an exception)
        assertThrows(IllegalArgumentException.class, () -> taskService.updateTask("999", "Updated Task", "Updated Description"));
    }

    @Test
    public void testUpdateTaskWithNullValues() {
        Task task = new Task("1", "Test Task", "Test Description");

        // Add the task
        taskService.addTask(task);

        // Update only the description
        taskService.updateTask("1", null, "New Description");

        // Verify only the description is updated
        assertEquals("Test Task", task.getName());
        assertEquals("New Description", task.getDescription());
    }

    @Test
    public void testGetTask() {
        Task task = new Task("1", "Test Task", "Test Description");

        // Add the task
        taskService.addTask(task);

        // Verify the task is retrieved successfully
        assertEquals(task, taskService.getTask("1"));
    }

    @Test
    public void testGetTaskWithNonExistingId() {
        // Attempt to get a task that doesn't exist (should return null)
        assertNull(taskService.getTask("999"));
    }
}
