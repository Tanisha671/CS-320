package Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import Contact.Contact;

public class ContactTest {

    // Test constructor with valid data
    @Test
    public void testContactCreation() {
        Contact contact = new Contact("1234", "Zion", "Dun", "1234567890", "Lane St");
        assertNotNull(contact);
        assertEquals("1234", contact.getContactId());
        assertEquals("Zion", contact.getFirstName());
        assertEquals("Dun", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("Lane St", contact.getAddress());
    }

    // Test setter methods for valid updates
    @Test
    public void testSetters() {
        Contact contact = new Contact("1234", "Zion", "Dun", "1234567890", "Lane St");

        // Valid updates
        contact.setFirstName("UpdatedZ");
        contact.setLastName("UpdatedD");
        contact.setPhone("0987654321");
        contact.setAddress("Updated Lane St");

        assertEquals("UpdatedZ", contact.getFirstName());
        assertEquals("UpdatedD", contact.getLastName());
        assertEquals("0987654321", contact.getPhone());
        assertEquals("Updated Lane St", contact.getAddress());
    }

    
    // Test for valid Contact ID length (edge case of exactly 10 characters)
    @Test
    public void testValidContactIdLength() {
        Contact contact = new Contact("1234567890", "Zion", "Dun", "1234567890", "Lane St");
        assertEquals("1234567890", contact.getContactId());
    }

    // Test valid first name length (edge case of exactly 10 characters)
    @Test
    public void testValidFirstNameLength() {
        Contact contact = new Contact("1234", "Zion", "Dun", "1234567890", "Lane St");
        assertEquals("Zion", contact.getFirstName());
    }

    // Test valid phone length (exactly 10 digits)
    @Test
    public void testValidPhoneLength() {
        Contact contact = new Contact("1234", "Zion", "Dun", "1234567890", "Lane St");
        assertEquals("1234567890", contact.getPhone());
    }

    // Test valid address length (edge case of exactly 30 characters)
    @Test
    public void testValidAddressLength() {
        Contact contact = new Contact("1234", "Zion", "Dun", "1234567890", "123456789012345678901234567890");
        assertEquals("123456789012345678901234567890", contact.getAddress());
    }

   

    // **First Name Setter Branch Coverage**
    @Test
    public void testFirstNameSetter() {
        Contact contact = new Contact("1234", "Zion", "Dun", "1234567890", "Lane St");

        // Test when first name is null (should throw exception)
        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName(null));

        // Test when first name length is greater than 10 (should throw exception)
        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName("ThisNameIsWayTooLong"));
    }

    // **Last Name Setter Branch Coverage**
    @Test
    public void testLastNameSetter() {
        Contact contact = new Contact("1234", "Zion", "Dun", "1234567890", "Lane St");

        // Test when last name is null (should throw exception)
        assertThrows(IllegalArgumentException.class, () -> contact.setLastName(null));

        // Test when last name length is greater than 10 (should throw exception)
        assertThrows(IllegalArgumentException.class, () -> contact.setLastName("ThisLastNameIsWayTooLong"));
    }

    // **Phone Setter Branch Coverage**
    @Test
    public void testPhoneSetter() {
        Contact contact = new Contact("1234", "Zion", "Dun", "1234567890", "Lane St");

        // Test when phone is null (should throw exception)
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone(null));

        // Test when phone length is not 10 (should throw exception)
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone("12345"));

        // Test when phone contains non-numeric characters (should throw exception)
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone("1234abc890"));
    }

    
}
