package Test;

import Appointment.Appointment;
import Appointment.AppointmentService;
import org.junit.jupiter.api.Test;

import java.util.Calendar;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

public class AppointmentServiceTest {

    @Test
    public void testAddAppointment() {
        AppointmentService appointmentService = new AppointmentService();
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.HOUR, 1);  // Set appointment for 1 hour in the future
        Date futureDate = calendar.getTime();

        Appointment appointment = new Appointment("T123", futureDate, "Doctor visit");

        appointmentService.addAppointment(appointment);
        assertNotNull(appointmentService.getAppointment("T123"));
    }

    @Test
    public void testAddDuplicateAppointment() {
        AppointmentService appointmentService = new AppointmentService();
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.HOUR, 1);  // Set appointment for 1 hour in the future
        Date futureDate1 = calendar.getTime();
        calendar.add(Calendar.HOUR, 1);  // Set a different future date for second appointment
        Date futureDate2 = calendar.getTime();

        Appointment appointment1 = new Appointment("T123", futureDate1, "Doctor visit");
        Appointment appointment2 = new Appointment("T123", futureDate2, "Dentist visit");

        appointmentService.addAppointment(appointment1);
        assertThrows(IllegalArgumentException.class, () -> appointmentService.addAppointment(appointment2));
    }

    @Test
    public void testDeleteAppointment() {
        AppointmentService appointmentService = new AppointmentService();
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.HOUR, 1);  // Set appointment for 1 hour in the future
        Date futureDate = calendar.getTime();

        Appointment appointment = new Appointment("T123", futureDate, "Doctor visit");

        appointmentService.addAppointment(appointment);
        appointmentService.deleteAppointment("T123");
        assertNull(appointmentService.getAppointment("T123"));
    }

    @Test
    public void testDeleteNonExistentAppointment() {
        AppointmentService appointmentService = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> appointmentService.deleteAppointment("A999"));
    }

    @Test
    public void testAddNullAppointment() {
        AppointmentService appointmentService = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> appointmentService.addAppointment(null));
    }

    @Test
    public void testDeleteAppointmentWithNullId() {
        AppointmentService appointmentService = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> appointmentService.deleteAppointment(null));
    }
}
    