package Test;

import org.junit.jupiter.api.Test;
import Appointment.Appointment;
import Appointment.AppointmentService;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;

public class AppointmentTest {

    @Test
    public void testValidAppointment() {
        // Create a valid appointment (date in the future)
        Appointment appointment = new Appointment("A123", new Date(System.currentTimeMillis() + 100000), "Dentist appointment");

        // Validate the appointment properties
        assertNotNull(appointment);
        assertEquals("A123", appointment.getAppointmentId());
        assertTrue(appointment.getAppointmentDate().after(new Date())); // Check that the date is in the future
        assertEquals("Dentist appointment", appointment.getDescription()); // Check that description matches
    }

    @Test
    public void testAppointmentIdBoundary() {
        // Test valid appointment with exactly 10 characters for appointment ID
        Appointment appointment = new Appointment("1234567890", new Date(System.currentTimeMillis() + 100000), "Valid ID");
        assertNotNull(appointment);
        assertEquals("1234567890", appointment.getAppointmentId()); // Check if appointment ID matches
    }
    
    @Test
    public void testAppointmentDescriptionBoundary() {
        // Test valid appointment with description of exactly 50 characters
        String description = "This is exactly fifty characters in length.";
        Appointment appointment = new Appointment("T123", new Date(System.currentTimeMillis() + 100000), description);
        assertNotNull(appointment);
        assertEquals(description, appointment.getDescription()); // Check if description matches

        // Test invalid appointment description (too long)
        String longDescription = "This description exceeds fifty characters in length!";
        assertThrows(IllegalArgumentException.class, () -> new Appointment("T124", new Date(System.currentTimeMillis() + 100000), longDescription));
    }

    

    @Test
    public void testAppointmentWithCurrentDate() {
        // Create an appointment with the current date (edge case)
        Date currentDate = new Date();
        Appointment appointment = new Appointment("T125", currentDate, "Appointment for current date");

        // Validate that the appointment was successfully created
        assertNotNull(appointment);
        assertEquals(currentDate, appointment.getAppointmentDate()); // Check if the date matches
        assertEquals("Appointment for current date", appointment.getDescription()); // Validate description
    }

    @Test
    public void testDeleteAppointment() {
        // Assuming AppointmentService is available to add and delete appointments
        AppointmentService appointmentService = new AppointmentService();

        String appointmentId = "T126";
        Date appointmentDate = new Date(System.currentTimeMillis() + 100000);
        String description = "Test appointment for deletion";
        Appointment appointment = new Appointment(appointmentId, appointmentDate, description);
        appointmentService.addAppointment(appointment);

        // Ensure the appointment exists before deletion
        assertNotNull(appointmentService.getAppointment(appointmentId));

        // Delete the appointment
        boolean deleteResult = appointmentService.deleteAppointment(appointmentId);
        assertTrue(deleteResult); // Should return true, appointment deleted successfully

        // Ensure the appointment no longer exists after deletion
        assertNull(appointmentService.getAppointment(appointmentId));
    }

    @Test
    public void testGetAllAppointments() {
        // Assuming AppointmentService can return a list of all appointments
        AppointmentService appointmentService = new AppointmentService();

        // Create appointments and add them to the service
        Appointment appointment1 = new Appointment("A127", new Date(System.currentTimeMillis() + 200000), "Meeting");
        Appointment appointment2 = new Appointment("A128", new Date(System.currentTimeMillis() + 300000), "Conference");

        // Add appointments to the service
        appointmentService.addAppointment(appointment1);
        appointmentService.addAppointment(appointment2);

        // Get all appointments and assert the size
        assertEquals(2, appointmentService.getAllAppointments().size()); // Expecting 2 appointments
    }
}
