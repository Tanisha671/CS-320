package Appointment;

import java.util.Date;

public class Appointment {
    private final String appointmentId;
    private final Date appointmentDate;
    private final String description;

    // Constructor to initialize the Appointment object
    public Appointment(String appointmentId, Date appointmentDate, String description) {
        // Validate the appointment ID (must not be null and should not exceed 10 characters)
        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Appointment ID must not be null or exceed 10 characters.");
        }

        // Validate the appointment date (must not be in the past)
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date cannot be in the past.");
        }

        // Validate the description (must not be null and should not exceed 50 characters)
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Description must not be null or exceed 50 characters.");
        }

        // If validation passes, initialize the fields
        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }

    // Getter for appointmentId
    public String getAppointmentId() {
        return appointmentId;
    }

    // Getter for appointmentDate
    public Date getAppointmentDate() {
        return appointmentDate;
    }

    // Getter for description
    public String getDescription() {
        return description;
    }
}