package Appointment;

import java.util.HashMap;
import java.util.Map;
import java.util.*;

public class AppointmentService {
    private Map<String, Appointment> appointments = new HashMap<>();

    public boolean deleteAppointment(String appointmentId) {
        // Check if the appointment exists and remove it
        if (appointmentId == null || !appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment with ID " + appointmentId + " does not exist.");
        }
        appointments.remove(appointmentId);  // Remove the appointment
        return true;  // Return true if deleted successfully
    }

    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);  // Return the appointment by ID
    }

    public List<Appointment> getAllAppointments() {
        return new ArrayList<>(appointments.values());  // Return all appointments
    }

    public void addAppointment(Appointment appointment) {
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment cannot be null.");
        }

        // Check if the appointment ID already exists in the map
        if (appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Appointment with this ID already exists.");
        }

        appointments.put(appointment.getAppointmentId(), appointment);  // Add appointment to the map
    }
}
